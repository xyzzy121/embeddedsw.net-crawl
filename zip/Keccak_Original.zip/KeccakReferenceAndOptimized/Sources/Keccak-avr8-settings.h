#define	cKeccakR	1024

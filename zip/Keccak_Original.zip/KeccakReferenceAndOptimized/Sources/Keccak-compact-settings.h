#define cKeccakB    800
#define cKeccakR    512
//#define cKeccakFixedOutputLengthInBytes 64

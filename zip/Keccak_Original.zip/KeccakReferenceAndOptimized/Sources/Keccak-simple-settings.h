#define cKeccakB    1600
#define cKeccakR    1024
//#define cKeccakFixedOutputLengthInBytes 64

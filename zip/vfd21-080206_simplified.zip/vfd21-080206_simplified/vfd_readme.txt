
This is a simplified version of the open source program VFD 2.1.
Find the original program at:
- http://chitchat.at.infoseek.co.jp/vmware/vfd.html

Visit VFD-simplified & EMUFDD (USB floppy disk drive replacement) at
- www.milosrl.it
- http://embeddedsw.net/EMUFDD_Floppy_Hardware_Emulator_Home.html

Italy 9/7/2011

In order to build the VFD with ZIP compressed image support,

- get zlib123.zip from http://www.winimage.com/zLibDll/
  and extract the following files into this directory

    zlib.h      zconf.h

- get zlib123dll.zip from http://www.winimage.com/zLibDll/
  and extract the following file into this directory

    zlibstat.lib
